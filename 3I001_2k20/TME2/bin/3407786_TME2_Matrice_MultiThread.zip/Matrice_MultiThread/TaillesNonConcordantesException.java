public class TaillesNonConcordantesException extends Exception
{
	private static final long serialVersionUID = -546334959667730751L;

	public TaillesNonConcordantesException(String message)
	{
		super(message);
	}
}